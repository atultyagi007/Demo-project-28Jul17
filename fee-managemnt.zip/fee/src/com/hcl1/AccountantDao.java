package com.hcl1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hcl.AccountantBean;
import com.hcl.StudentBean;
import com.javawebtutor.hibernate.util.HibernateUtil;


public class AccountantDao {
	
public static int save(AccountantBean bean){
	int status=0;
	Connection con=null;
	Session session=null;
	Transaction tx=null;
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		session.save(bean);
		
		tx.commit();
		status=1;
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	return status;
}
public static boolean validate(String email,String password){
	boolean status=false;
	Session session=null;
	Transaction tx=null;
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		String sql="from AccountantBean where email=? and password=?";
		Query q=session.createQuery(sql);
		q.setParameter(0, email);
		q.setParameter(1,password );
		AccountantBean u = (AccountantBean)q.uniqueResult();
        tx.commit();
        if(u!=null) status=true;
		
			
		
		
		
	}catch(Exception ex){System.out.println(ex);}
	return status;
}
public static int update(AccountantBean bean){
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		AccountantBean ab=(AccountantBean)session.load(AccountantBean.class,bean.getId());
		ab.setName(bean.getName());
		ab.setEmail(bean.getEmail());
		ab.setPassword(bean.getPassword());
		ab.setAddress(bean.getAddress());
		ab.setContact(bean.getContact());
		session.update(ab);
		tx.commit();
		status=1;
		
	}catch(Exception ex){System.out.println(ex);}
	return status;
}	

public static int delete(int id){
	int status=0;
	Session session=null;
	Transaction tx=null;
	
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		AccountantBean ab=(AccountantBean)session.load(AccountantBean.class,id);
		
		session.delete(ab);
		tx.commit();
		status=1;
		
	}catch(Exception ex){System.out.println(ex);}
	return status;
}

public static List<AccountantBean> getAllRecords(){
	List<AccountantBean> list=new ArrayList<AccountantBean>();;
	Session session=null;
	Transaction tx=null;
	try{
	
		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		String sql="from AccountantBean ";
		Query q=session.createQuery(sql);
		list=q.list();
		tx.commit();
		
		
		}catch(Exception ex)
	{System.out.println(ex);}
	
	return list;
}

public static AccountantBean getRecordById(int id){
	AccountantBean bean=new AccountantBean();
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{
		
		session=HibernateUtil.getSessionImpl();
	    tx = session.beginTransaction();
		String sql="from AccountantBean act  where act.id=?";
		Query q=session.createQuery(sql);
		q.setParameter(0, id);
		//q.list();
     
		bean = (AccountantBean)q.uniqueResult();
        tx.commit();

		
	}catch(Exception ex){System.out.println(ex);}
	
	return bean;
}
}
