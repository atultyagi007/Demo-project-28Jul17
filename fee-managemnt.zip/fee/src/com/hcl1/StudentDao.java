package com.hcl1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hcl.AccountantBean;
import com.hcl.StudentBean;
import com.javawebtutor.hibernate.util.HibernateUtil;
public class StudentDao {
	
public static int save(StudentBean bean){
	int status=0;
	Connection con=null;
	Session session=null;
	Transaction tx=null;
	try{
		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		session.save(bean);
		
		tx.commit();
		status=1;
		
	}catch(Exception ex)
	{
		System.out.println(ex);
	}
	return status;
}
public static int update(StudentBean bean){
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{

		
		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		StudentBean ab=(StudentBean)session.load(StudentBean.class,bean.getRollno());
		ab.setName(bean.getName());
		ab.setEmail(bean.getEmail());
		ab.setSex(bean.getSex());
		ab.setCourse(bean.getCourse());
		ab.setFee(bean.getFee());
		ab.setPaid(bean.getPaid());
		ab.setDue(bean.getDue());
		ab.setAddress(bean.getAddress());
		ab.setContact(bean.getContact());
		session.update(ab);
		tx.commit();
		status=1;
		
	}catch(Exception ex){System.out.println(ex);}
	return status;
}	

		
		
public static int delete(int rollno){
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		StudentBean ab=(StudentBean)session.load(StudentBean.class,rollno);
		
		session.delete(ab);
		tx.commit();
		status=1;
	}catch(Exception ex){System.out.println(ex);}
	return status;
}
public static int deleteByName(String name){
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{

		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		StudentBean ab1=(StudentBean)session.load(StudentBean.class,name);
		
		session.delete(ab1);
		tx.commit();
		status=1;
		
	}catch(Exception ex){System.out.println(ex);}
	return status;
}

public static List<StudentBean> getAllRecords(){
	List<StudentBean> list=new ArrayList<StudentBean>();
	Session session=null;
	Transaction tx=null;
	try{
		
		
		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		String sql="from StudentBean ";
		Query q=session.createQuery(sql);
		list=q.list();
		tx.commit();
		
	}catch(Exception ex){System.out.println(ex);}
	
	return list;
}
public static List<StudentBean> getDues(){
	List<StudentBean> list=new ArrayList<StudentBean>();
	Session session=null;
	Transaction tx=null;
	try{
		
		session=HibernateUtil.getSessionImpl();
		tx = session.beginTransaction();
		String sql="from StudentBean ";
		Query q=session.createQuery(sql);
		list=q.list();
		tx.commit();
	}catch(Exception ex){System.out.println(ex);}
	
	return list;
}

public static StudentBean getRecordByRollno(int rollno){
	StudentBean bean=new StudentBean();
	int status=0;
	Session session=null;
	Transaction tx=null;
	try{
        session=HibernateUtil.getSessionImpl();
	    tx = session.beginTransaction();
		String sql="from StudentBean act  where act.id=?";
		Query q=session.createQuery(sql);
		q.setParameter(0, rollno);
		//q.list();
     
		bean = (StudentBean)q.uniqueResult();
        tx.commit();

		
		
		
	}catch(Exception ex){System.out.println(ex);}
	
	return bean;
}

}