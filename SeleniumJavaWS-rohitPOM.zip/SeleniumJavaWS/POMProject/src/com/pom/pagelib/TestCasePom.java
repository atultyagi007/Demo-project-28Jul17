package com.pom.pagelib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestCasePom {
	public WebDriver drv;
	public HomePage home;

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.gecko.driver",
				"Z:\\Users\\rohit.srivastava\\Desktop\\Selenium-jars-java\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		drv = new FirefoxDriver();
		drv.get("https://www.myhcl.com/Login/home.aspx");
		drv.manage().window().maximize();

	}

	@Test
	public void TestLogin() {
		LoginPage lgn = new LoginPage(drv);

		lgn.typeUserName("rohit_sr");

		lgn.typePassword("1234");

		home = lgn.clickSubmit();
	}

	@AfterTest
	public void cleanup() {
		//drv.quit();
	}
}
