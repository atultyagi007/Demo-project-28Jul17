package com.pom.pagelib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	public WebDriver driver;

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "txtUserID")
	private WebElement userName;

	@FindBy(id = "txtPassword")
	private WebElement password;

	@FindBy(id = "btnSubmit")
	private WebElement submit;

	public void typeUserName(String text) {
		userName.sendKeys(text);
	}

	public void typePassword(String text) {
		password.sendKeys(text);
	}

	public HomePage clickSubmit() {
		submit.click();
		return new HomePage(driver);
	}

	public HomePage loginWithValidCredentials(String userName, String pwd) {
		typeUserName(userName);
		typePassword(pwd);
		return clickSubmit();
	}

}
