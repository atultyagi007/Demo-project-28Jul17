import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestGeco {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver",
				"Z:\\Users\\rohit.srivastava\\Desktop\\Selenium-jars-java\\geckodriver-v0.16.1-win64\\geckodriver.exe");

		WebDriver drv = new FirefoxDriver();

		drv.get("https://www.myhcl.com/Login/home.aspx");

		drv.manage().window().maximize();

		drv.findElement(By.id("txtUserID")).sendKeys("demo123");

		drv.findElement(By.id("txtPassword")).sendKeys("demo123");

		drv.findElement(By.id("ddlDomain")).click();

		new Select(drv.findElement(By.id("ddlDomain"))).selectByValue("ASSOCIATES");
		
		drv.findElement(By.id("btnSubmit")).click();

	}

}
