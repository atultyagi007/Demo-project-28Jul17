package com.hcl;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.io.*;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 

public class Search extends HttpServlet
{
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int size=0;
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();      
		String name=req.getParameter("uname");

		try{
			Class.forName("com.mysql.jdbc.Driver");
			//String query;
			//String med_name, manu_date,exp_date,type,quantity,price; 
			Connection  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ns","root","Golu@#5891");

			
            if (name != ""){
            	PreparedStatement ps=con.prepareStatement("select * from medicine1 where med_name=?");
    			ps.setString(1,name);
    			
    			out.print("<center>");
    			out.print("<table width=25% border=1>");
    			out.print("<center><h1><u>Result:</u></h1></center>");
    			
    			

    			ResultSet rs=ps.executeQuery();                 
    			ResultSetMetaData rsmd=rs.getMetaData();
    			while(rs.next())
    			{
    				out.print("<tr>");

    				out.print("<td>"+rsmd.getColumnName(1)+"</td>");
    				out.print("<td>"+rs.getString(1)+"</td></tr>");

    				out.print("<tr><td>"+rsmd.getColumnName(2)+"</td>");
    				out.print("<td>"+rs.getString(2)+"</td></tr>");

    				out.print("<tr><td>"+rsmd.getColumnName(3)+"</td>");
    				out.print("<td>"+rs.getString(3)+"</td></tr>");

    				out.print("<tr><td>"+rsmd.getColumnName(4)+"</td>");
    				out.print("<td>"+rs.getString(4)+"</td></tr>");      

    				out.print("<tr><td>"+rsmd.getColumnName(5)+"</td>");
    				out.print("<td>"+rs.getString(5)+"</td></tr>");

    				out.print("<tr><td>"+rsmd.getColumnName(6)+"</td>");
    				out.print("<td>"+rs.getString(6)+"</td></tr>");               
    			}
            }
			
            else
			{
			PreparedStatement ps1=con.prepareStatement("select * from medicine1");
			ResultSet rs1=ps1.executeQuery();
			//ResultSet rs=ps.executeQuery();                 
			//ResultSetMetaData rsmd=rs.getMetaData();
			out.print("<center>");
			out.print("<table width=100% border=1>");
			out.print("<center><h1><u>Result:</u></h1></center>");
			
			out.print("<tr>"); 
			
			out.print("<td>");
	    	out.print("<b>");
	    	out.print("Medicine Name");
	    	out.print("</b>");
	    	out.print("</td>");
	    	
	     	out.print("<td>");
	     	out.print("<b>");
	     	out.print("Manufacturing Date");
	     	out.print("</b>");
	     	out.print("</td>");
	     	
	     	out.print("<td>");
	     	out.print("<b>");
	    	out.print("Expiry Date");
	    	out.print("</b>");
	    	out.print("</td>");
	     	
	    	out.print("<td>");
	    	out.print("<b>");
	    	out.print("Type");
	    	out.print("</b>");
	    	out.print("</td>");

	    	out.print("<td>");
	    	out.print("<b>");
	    	out.print("Price");
	    	out.print("</b>");
	    	out.print("</td>");
	    	
	    	out.print("<td>");
	    	out.print("<b>");
	    	out.print("Quantity");
	    	out.print("</b>");
	    	out.print("</td>");
	    	
	    	out.print("</tr>");
	    	
			while(rs1.next())
			{
				out.print("<tr>");

				//out.print("<td>"+rsmd.getColumnName(1)+"</td>");
				out.print("<td>"+rs1.getString(1)+"</td>");

				//out.print("<tr><td>"+rsmd.getColumnName(2)+"</td>");
				out.print("<td>"+rs1.getString(2)+"</td>");

				//out.print("<tr><td>"+rsmd.getColumnName(3)+"</td>");
				out.print("<td>"+rs1.getString(3)+"</td>");

				//out.print("<tr><td>"+rsmd.getColumnName(4)+"</td>");
				out.print("<td>"+rs1.getString(4) +"</td>");      

				//out.print("<tr><td>"+rsmd.getColumnName(5)+"</td>");
				out.print("<td>"+rs1.getString(5)+"</td>");

				//out.print("<tr><td>"+rsmd.getColumnName(6)+"</td>");
				out.print("<td>"+rs1.getString(6)+"</td>"); 
				out.print("</tr>");
			}
			}

			out.print("</table>");
			out.print("<a href=\"cart.html\">Move to Your Account!!</a>");
			out.print("</center>");

		}
		catch (Exception e2)
		{
			e2.printStackTrace();
		}
		finally
		{
			out.close();
		}
		}
}