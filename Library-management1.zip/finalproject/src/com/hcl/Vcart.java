package com.hcl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Vcart  extends HttpServlet 
 {
	static float total=0;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		     		  		   
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String med_name=request.getParameter("med_name");
        String price=request.getParameter("price");
        String qorder=request.getParameter("qorder");
	
    
      try{

	
         Class.forName("com.mysql.jdbc.Driver");

         Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ns","root","Golu@#5891");
         Statement s = con.createStatement();
         ResultSet rsmd=s.executeQuery("select medicine1.price,cart2.qorder from medicine1 inner join cart2 on cart2.med_name=medicine1.med_name;");
         
         out.print("<center>");
         out.print("<table width=25% border=1>");

         out.print("<center><h1><u>Result:</u></h1></center>");
         out.print("<tr>");
     	out.print("<td>");
     	out.print("<b>");
     	out.print("Medicine Price");
     	out.print("</b>");
     	
     	out.print("<td>");
     	out.print("<b>");
    	out.print("Quantity Ordered");
    	out.print("</b>");
    	out.print("</td>");
     	
    	out.print("<td>");
    	out.print("<b>");
    	out.print("Amount");
    	out.print("</b>");
    	out.print("</td>");
    	out.print("</tr>");
     	



         while(rsmd.next())
            {
        	out.print("<tr>");
        	out.print("<td>"+rsmd.getString(1)+"</td>");
        	out.print("<td>"+rsmd.getString(2)+"</td>");
        	float s1=Float.parseFloat(rsmd.getString(1));
        	float s2=Float.parseFloat(rsmd.getString(2));
        	float cal=s1*s2;
        	out.print("<td>"+cal+"</td>");
            out.print("</tr>");
            total=total+cal;
         }
         out.print("<tr><td><b>Total Amount</b></td><td></td><td><b>"+total+"</b></td></tr>");
         out.print("</table>");
         
         out.print("<a href=\"https://www.paypal.com/us/home\">Pay Bill!!</a>");
         out.print("</center>");
         
      	}
      catch(Exception e)
      {
    	  e.printStackTrace();
      }

finally{out.close();
}
	}
 }
