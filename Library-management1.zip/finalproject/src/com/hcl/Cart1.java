package com.hcl;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Cart1 extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String med_name = request.getParameter("med_name");
		String qorder = request.getParameter("qorder");

		int qo=Integer.parseInt(qorder);

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ns","root","Golu@#5891");

			PreparedStatement ps2=con.prepareStatement("select quantity from medicine1 where med_name=? ;");             
			ps2.setString(1,med_name);
			int newq=0,q=0;
			ResultSet rs=ps2.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString("quantity"));

				q=Integer.parseInt(rs.getString("quantity"));
				newq=q-qo;
			}	

			if(q<qo)
			{
				out.println("<script type='text/javascript'>alert('Quantity ordered is more than the available quantity')</script>");					
			}
			else
			{
				PreparedStatement ps1=con.prepareStatement("insert  into cart2 values(?,?)");
				ps1.setString(1,med_name);
				ps1.setString(2,qorder);
				int i=ps1.executeUpdate();
				if(i>0)
				{
					out.println("<script type='text/javascript'>alert('submitted successfully!')</script>");

					PreparedStatement ps3=con.prepareStatement("update medicine1 set quantity="+newq+" where med_name=? ;");
					ps3.setString(1,med_name);
					ps3.executeUpdate();
				}
			}
		}
		catch(Exception se)
		{
			se.printStackTrace();
		}

	}
}





