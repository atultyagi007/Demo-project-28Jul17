package com.hcl;

import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;    
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/ViewServlet")  
public class ViewServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException {  
        response.setContentType("text/html");  
       PrintWriter out=response.getWriter();  
        out.println("<a href='medadmin.html'>Add New Medicine</a>");  
       out.println("<h1>Medicine list</h1>");  
        List<Emp> list=EmpDao.getAllEmployees();  
          
        out.print("<table border='1' width='100%'");  
        out.print("<tr><th>Medicine Name</th><th>Manufacturing date</th><th>Expiry date</th><th>Type</th><th>Price</th><th>Quantity</th><th>Edit</th><th>Delete</th></tr>");  
       for(Emp e:list){  
        out.print("<tr><td>"+e.getMedicine_Name()+"</td><td>"+e.getManufacturing_date()+"</td><td>"+e.getExpiry_date()+"</td><td>"+e.getType()+"</td><td>"+e.getPrice()+"</td><td>"+e.getQuantity()+"</td><td><a href='EditServlet?med_name="+e.getMedicine_Name()+"'>edit</a></td><td><a href='DeleteServlet?med_name="+e.getMedicine_Name()+"'>delete</a></td></tr>");  
       }  
       out.print("</table>");  
          
        out.close();  
    }  
}  
