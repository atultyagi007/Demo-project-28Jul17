package com.hcl;


public class Emp 
{  
	private int quantity; 
	private String manu_date, exp_date;
	private double price;


	private String name,med_type,country;  

	public String getMedicine_Name() {  
		return name;  
	}  
	public void setMedicine_Name(String name) {  
		this.name = name;  
	}  
	
	
	
	
	public String  getManufacturing_date() {  
		return manu_date;  
	}  
	public void setManufacturing_date(String manu_date) {  
		this.manu_date = manu_date;  
	}  
	
	public String getExpiry_date() {  
		return exp_date;  
	}  
	public void setExpiry_date(String exp_date) {  
		this.exp_date = exp_date;  
	}  
	
	
	
	
	
	public String getType() {  
		return med_type;  
	}  
	public void setType(String med_type) {  
		this.med_type = med_type;  
	}  


	public double getPrice() {  
		return price;  
	}  
	public void setPrice(double price) {  
		this.price = price;  
	}


	public int  getQuantity() {  
		return quantity;  
	}  
	public void setQuantity(int quantity) {  
		this.quantity = quantity;  

	}
}  
