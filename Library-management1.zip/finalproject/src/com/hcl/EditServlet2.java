package com.hcl;

import java.io.IOException;  
import java.io.PrintWriter;  

import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/EditServlet2")  
public class EditServlet2 extends HttpServlet 
{  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{  
		response.setContentType("text/html");  
		PrintWriter out=response.getWriter();  

		String name=request.getParameter("med_name");  

		String mdate=request.getParameter("manu_date");
		//int manu_date=Integer.parseInt(mdate);

		String edate=request.getParameter("exp_date");
		//int exp_date=Integer.parseInt(edate);

		String med_type=request.getParameter("med_type");

		String price=request.getParameter("med_price");
		double price1=Double.parseDouble(price);


		String Qu=request.getParameter("med_quantity");
		int quantity=Integer.parseInt(Qu);

		Emp e=new Emp();  
		e.setMedicine_Name(name);  
		e.setManufacturing_date(mdate);
		e.setExpiry_date(edate); 
		e.setType(med_type);
		e.setPrice(price1);
		e.setQuantity(quantity);  
		out.println(e);
		int status=EmpDao.update(e);  
		if(status>0)
		{  
			response.sendRedirect("ViewServlet");  
		}
		else
		{  
			out.println("Sorry! unable to update record");  
		}  
		out.close();  
	}  

}  
