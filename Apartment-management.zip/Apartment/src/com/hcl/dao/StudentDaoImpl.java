package com.hcl.dao;

import com.hcl.bean.NewStuReg;
import java.sql.*;

import javax.swing.JOptionPane;

import com.hcl.connection.*;

public class StudentDaoImpl  {
	
	
	public StudentDaoImpl()
	{
		
		
	}
	
	static int available;
	static int occupied;

	public static int insert(NewStuReg nsr) {
		int status=0, roomStatus=0 , stuStatus=0;  
		try{  
		Connection con=ConnectionProvider.getCon();  		
		
		PreparedStatement ps=con.prepareStatement("insert into Student_Reg (sname,sfname,sage,sgender,saddress,scontact,sdoj,sdol,sroom) values (?,?,?,?,?,?,?,?,?);");  
		System.out.println(nsr.getName());
		System.out.println(con);
		ps.setString(1,nsr.getName());  
		ps.setString(2,nsr.getFname());  
		ps.setInt(3,nsr.getAge());
		ps.setString(4,nsr.getGender());
		ps.setString(5,nsr.getAddress());
		ps.setString(6,nsr.getContact());
		ps.setString(7,nsr.getDoj()); 
		ps.setString(8,nsr.getDol());
		String room=nsr.getApp()+nsr.getFloor()+nsr.getRoom();
		ps.setString(9, room);
		           
		roomStatus=roomUpdate(room);
		
		
		stuStatus=ps.executeUpdate();  
		
		if(roomStatus>=1 && stuStatus >=1)
		status=1;
		else
			status=0;
		
		}
		catch(Exception e){
			e.printStackTrace();
		}  
		
		return status;  

		
	}
	
	
	public static boolean roomStatus(String room)
	{
		boolean status =false;
		try
		{
		Connection con=ConnectionProvider.getCon(); 
		Statement st= con.createStatement();
		ResultSet rs= st.executeQuery("select * from "+room+" ;");
		status=rs.next();
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return status;
		
	}
	
	
	
	public static int roomAvailabe(String room)
	{
		
		int avail=0;
		try
		{
		Connection con=ConnectionProvider.getCon(); 
		Statement st= con.createStatement();
		ResultSet rs= st.executeQuery("select available from "+room+" ;");
		avail=rs.getInt("available");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return avail;
		
	}
	
	public static int roomOccupied(String room)
	{
		int occ=0;
		try
		{
		Connection con=ConnectionProvider.getCon(); 
		Statement st= con.createStatement();
		ResultSet rs= st.executeQuery("select occupied from "+room+" ;");
		occ=rs.getInt("occupied");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return occ;
		
	}
	
	
	
	public static int roomUpdate(String room)
	{
		
		int updateRoom=0;  
		
	if (roomStatus(room)==false)
	{
		available=3;
		occupied=0;
		
	}
	
	else
	{
		available=roomAvailabe(room);
		occupied=roomOccupied(room);
		
	}
		
	if(occupied>3)
	{
		JOptionPane.showMessageDialog(null, "This room is full , Please select another room !");
	}
	else
	{

	try{  
	Connection con=ConnectionProvider.getCon();  
	PreparedStatement ps=con.prepareStatement("insert into app_room values(?,?,?)");  
	ps.setString(1,room);  
	ps.setInt(2,available-1);  
	ps.setInt(3,occupied+1);  
	             
	updateRoom=ps.executeUpdate();  
	}catch(Exception e){}  
	     
	return updateRoom;  
	}
		
	return updateRoom;  
	}
	

}
