	package com.hcl.bean;

	public class NewStuReg {

	  private static String name;
	  private static String fname;
	  private static int age;
	  private static String gender;
	  private static String address;
	  private static String contact;
	  private static String doj;
	  private static String dol;
	  private static String app;
	  private static String floor;
	  private static String room;
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		NewStuReg.name = name;
	}
	public static String getFname() {
		return fname;
	}
	public static void setFname(String fname) {
		NewStuReg.fname = fname;
	}
	public static int getAge() {
		return age;
	}
	public static void setAge(int age) {
		NewStuReg.age = age;
	}
	public static String getGender() {
		return gender;
	}
	public static void setGender(String gender) {
		NewStuReg.gender = gender;
	}
	public static String getAddress() {
		return address;
	}
	public static void setAddress(String address) {
		NewStuReg.address = address;
	}
	public static String getContact() {
		return contact;
	}
	public static void setContact(String contact) {
		NewStuReg.contact = contact;
	}
	public static String getDoj() {
		return doj;
	}
	public static void setDoj(String doj) {
		NewStuReg.doj = doj;
	}
	public static String getDol() {
		return dol;
	}
	public static void setDol(String dol) {
		NewStuReg.dol = dol;
	}
	public static String getApp() {
		return app;
	}
	public static void setApp(String app) {
		NewStuReg.app = app;
	}
	public static String getFloor() {
		return floor;
	}
	public static void setFloor(String floor) {
		NewStuReg.floor = floor;
	}
	public static String getRoom() {
		return room;
	}
	public static void setRoom(String room) {
		NewStuReg.room = room;
	}
	  
	}



