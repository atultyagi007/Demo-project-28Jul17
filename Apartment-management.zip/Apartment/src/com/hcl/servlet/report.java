package com.hcl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class report extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	PrintWriter out=resp.getWriter();
	resp.setContentType("text/html");
	
	String bed=req.getParameter("beds");
	String roomId="";
	int countBed=0;
	out.print("<center><h2>");
	out.print("Room with available "+bed+" beds : <br/>");
	out.print("</h2></center>");
try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
Statement st= (Statement)con.createStatement();
out.print("<table style=\"width:100%\"   border=\"1\" bgcolor='#C39BD3'>");
out.println("<tr><th bgcolor='#D0D3D4'>Appartment Type</th><th bgcolor='#D0D3D4'>Room Numbers</th></tr>");

for(int i=1;i<=2;i++)
{
	out.print("<tr><td>");
	if(i==1)
		out.print("For Appartment type A : <br/>");
	
	else
		out.print("For Appartment type B :  <br/>");
	out.print("</td><td>");
	
for(int j=1;j<=2;j++)
{
for(int k=1;k<10;k++)
{
	countBed=0;
	if(i==1)
	roomId="A"+j+""+k;
	else
		roomId="B"+j+""+k;
	
	ResultSet rs= st.executeQuery("select * from Student_Reg where room_id='"+roomId+"' ;");

	while(rs.next())
		countBed++;
	
	if(countBed==0 && Integer.parseInt(bed)==3)
		out.print(" "+roomId+"</br>");
	
	else if(countBed==1 && Integer.parseInt(bed)==2)
		out.print(" "+roomId+"</br>");
	
	
	else if(countBed==2 && Integer.parseInt(bed)==1)
		out.print(" "+roomId+"</br>");
}
	
	
}

out.println("</td></tr>");

}
out.println("</table >");
	}
	catch(Exception ex)
	{
		out.println("<script type=\"text/javascript\">");
		   out.println("alert('Please select appropriate entry !');");
		   out.println("location='report.html';");
		   out.println("</script>");
		
	}
}

}
