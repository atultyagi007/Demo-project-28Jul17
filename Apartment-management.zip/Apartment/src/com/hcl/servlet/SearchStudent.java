package com.hcl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class SearchStudent extends HttpServlet {
	
	String sname,sfname,saddress,sdol,sdoj,sgender,apartment,contact;
	int age,floor,room;
	String roomId;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	PrintWriter out=resp.getWriter();
	resp.setContentType("text/html");
	String stuId=req.getParameter("sid");

	
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		
		 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","root");
		Statement st= (Statement)con.createStatement();
	ResultSet rs= st.executeQuery("select * from Student_Reg where sid="+stuId+" ;");
	

	
	
	while(rs.next())
	{
		
		sname=rs.getString("sname");
		sfname=rs.getString("sfname");
 age=rs.getInt("sage");
 if(rs.getString("sgender").equalsIgnoreCase("m"))
	 sgender="Male";
 else
	 sgender="Female";
 saddress=rs.getString("saddress");
 contact=rs.getString("scontact");
 sdoj=rs.getString("sdoj");
 sdol=rs.getString("sdol");
 apartment=rs.getString("app");
 floor=rs.getInt("floor");
 room=rs.getInt("room");
 roomId=rs.getString("room_id");
	}
	
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	
	
	
	out.print("<html>"
			+ "<head>"
			+"<title> Search Result </title>"
			+ "</head>"
			+ "<body>"
			+ "<center>"
			+ "<table border=\"1\">");
	
	out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Student Id:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+stuId+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Name of Candidate</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+sname+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Father's Name:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+sfname+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Age:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+age+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Gender:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+sgender+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Address :</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+saddress+"\"></td></tr>");


out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Contact Number:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+contact+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Date of Joining:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+sdoj+"\"></td></tr>");


out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Date of Leaving:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+sdol+"\"></td></tr>");


out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Appartment :</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+apartment+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Floor:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+floor+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Room No:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+room+"\"></td></tr>");

out.print("<tr><td><font face=\"areal\" size=\"4\" color=\"green\">Room ID:</font></td>");
out.print("<td><input type=\"text\" name=\"app\" size=\"30\" maxlength=\"2\" disabled=\"disabled\" value=\""+roomId+"\"></td></tr>");

out.println("</table>"
		+ "</center>"
		+ "</body>"
		+ "</html>");


}

}
