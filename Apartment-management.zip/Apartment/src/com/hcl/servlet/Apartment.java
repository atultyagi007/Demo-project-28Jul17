package com.hcl.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import java.sql.DriverManager;
import java.sql.ResultSet;


public class Apartment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   static int available=0;
   static int occupied=0;
    public Apartment() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int status=0, roomStatus=0 , stuStatus=0;  
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String fname=request.getParameter("fname");
		int age=Integer.parseInt(request.getParameter("age"));
		String Fgender=request.getParameter("gender");
		String gender="m";
		if(Fgender.equalsIgnoreCase("Female"))
		{gender="f";}		
		String address=request.getParameter("address");
	    String contact=request.getParameter("contact");
		String doj=request.getParameter("doj");
		String dol=request.getParameter("dol");
		String app=request.getParameter("app");
		int floor=Integer.parseInt(request.getParameter("floor"));
		int room=Integer.parseInt(request.getParameter("room"));
		String roomId=app+request.getParameter("floor").toString()+request.getParameter("room").toString();	
	try{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
		 PreparedStatement pre=(PreparedStatement)con.prepareStatement("insert into Student_reg (sname,sfname,sage,sgender,saddress,scontact,sdoj,sdol,app,floor,room,room_id) values(?,?,?,?,?,?,?,?,?,?,?,?);");
		 
		 pre.setString(1,name);
		 pre.setString(2, fname);
		 pre.setInt(3, age);
		 pre.setString(4, gender);
		 pre.setString(5,address);
		 pre.setString(6, contact);
		 pre.setString(7, doj);
		 pre.setString(8, dol);
		 pre.setString(9, app);
		 pre.setInt(10, floor);
		 pre.setInt(11, room);
		 pre.setString(12,roomId);
		
		 
		 
		 roomStatus=roomUpdate(roomId);
			if(roomStatus>=1)
			stuStatus=pre.executeUpdate();  
			
			
			if(roomStatus>=1 && stuStatus >=1)
			status=1;
			else
				status=0;
						 
if(status>0)
{
	out.println("<script type=\"text/javascript\">");
	   out.println("alert('Registeration successfull !');");
	   out.println("location='RegistrationForm.html';");
	   out.println("</script>");
	   
}
			 else
{
	out.println("<script type=\"text/javascript\">");
	   out.println("alert('Room is already full please choose another room!');");
	   out.println("location='RegistrationForm.html';");
	   out.println("</script>");	
}
	}
	
	catch(Exception e){
		
	e.printStackTrace();
	}
	}

	

	public static boolean roomStatus(String room)
	{
		boolean status =false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
				Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select * from app_room where room='"+room+"' ;");
		status=rs.next();
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return status;
		
	}
	
	
	
	public static int roomAvailabe(String room)
	{
		
		int avail=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
			Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select available from app_room where room='"+room+"' ;");
		while(rs.next())
		avail=rs.getInt("available");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return avail;
		
	}
	
	public static int roomOccupied(String room)
	{
		int occ=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
			Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select occupied from app_room where room='"+room+"' ;");
	while(rs.next())
		occ=rs.getInt("occupied");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return occ;
		
	}
	
	
	
	public static int roomUpdate(String room)
	{
		
		int updateRoom=0;  
		
	if (roomStatus(room)==false)
	{
		available=3;
		occupied=0;
		
	}
	
	else
	{
		available=roomAvailabe(room);
		occupied=roomOccupied(room);
		
	}
		
	if(roomStatus(room)==false)
	{
	try{  
		Class.forName("com.mysql.jdbc.Driver");
		
		 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");	
	 Statement st= (Statement)con.createStatement();
	 updateRoom= st.executeUpdate("insert into app_room (room,available,occupied) values ('"+room+"',"+(available-1)+","+(occupied+1)+");");	
//insert into app_room (room,available,occupied) values ('A11',2,1);
	
	}catch(Exception e){}  
	     
	return updateRoom;  
	}
	else
	{
		if(occupied<3 && occupied>=0)
		{
			
			try{  
				Class.forName("com.mysql.jdbc.Driver");
				
				 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
				
				 int roomid=roomId(room);
				 
				 Statement st= (Statement)con.createStatement();
				 updateRoom= st.executeUpdate("UPDATE app_room set available="+(available-1)+", occupied="+(occupied+1)+" where rid="+roomid+" ;");	
		
			}catch(Exception e){}  
			     
			return updateRoom;  
			
			
		}
		
			
	}
		
	return updateRoom;  
	}
	


	public static int roomId(String room)
	{
	int roomid=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
				Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select rid from app_room where room='"+room+"' ;");
		while(rs.next())
		{
			roomid=rs.getInt("rid");
			
		}
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return roomid;
		
	}

}
