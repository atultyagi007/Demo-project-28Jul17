package com.hcl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class DeleteStudent extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		PrintWriter out=resp.getWriter();
		String sid=req.getParameter("txtSid");
		int roomstatus=roomUpdate(sid);
	int studentstatus=deleteFromStudentTable(sid);
	if(roomstatus>0 && studentstatus>0)
		out.print("Deletion successfull");
		else
		{
			out.println("<script type=\"text/javascript\">");
			   out.println("alert('Something went wrong !');");
			   out.println("location='DeleteStudent.html';");
			   out.println("</script>");	
		}
		
	}
	
	public int deleteFromStudentTable(String sid)
	{
		int deleteStudent=0;
		try{  
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");	
		 Statement st= (Statement)con.createStatement();
		 deleteStudent= st.executeUpdate("Delete from Student_Reg where sid="+sid+" ;");	
	//insert into app_room (room,available,occupied) values ('A11',2,1);
	
		}catch(Exception e){}  
		return deleteStudent;
		
	}
	
	public static int roomID(String sid)
	{
	String roomno=null;
	int roomId=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
				Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select room_id from Student_Reg where sid="+sid+" ;");
		while(rs.next())
		{
			roomno=rs.getString("room_id");
			
		}
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
				Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select rid from app_room where room='"+roomno+"' ;");
		while(rs.next())
		{
			roomId=rs.getInt("rid");
			
		}
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		return roomId;
		
	}
		
	public static int roomAvailabe(int roomid)
	{
		
		int avail=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
			Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select available from app_room where rid="+roomid+" ;");
		while(rs.next())
		avail=rs.getInt("available");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return avail;
		
	}
	
	public static int roomOccupied(int roomid)
	{
		int occ=0;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");
			Statement st= (Statement)con.createStatement();
		ResultSet rs= st.executeQuery("select occupied from app_room where rid="+roomid+" ;");
	while(rs.next())
		occ=rs.getInt("occupied");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return occ;
		
	}
	
	
	public static int roomUpdate(String sid)
	{
		
		int updateRoom=0, available, occupied, roomId;
		roomId=roomID(sid);
		available=roomAvailabe(roomId);
		occupied=roomOccupied(roomId);
		
	
	try{  
		Class.forName("com.mysql.jdbc.Driver");
		
		 Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/anand","root","anand");	
	 Statement st= (Statement)con.createStatement();
	 updateRoom= st.executeUpdate("update app_room set available="+(available+1)+" , occupied="+(occupied-1)+" where rid="+roomId+" ;");	
//UPDATE tutorials_tbl SET tutorial_title = 'Learning JAVA' WHERE tutorial_id = 3;
	
	}catch(Exception e){}  
	     
		
	return updateRoom;  
	}
	

	
	
	
}
