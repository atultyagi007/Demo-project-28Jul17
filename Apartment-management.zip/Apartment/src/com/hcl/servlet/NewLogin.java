package com.hcl.servlet;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;

public class NewLogin extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	PrintWriter out=resp.getWriter();
	resp.setContentType("text/html");
	String uname=req.getParameter("uid");
		String upass=req.getParameter("pid");
	
		if(uname.equalsIgnoreCase("admin") && upass.equalsIgnoreCase("admin"))
		{
			 req.getSession().setAttribute("user", uname);            
		       resp.sendRedirect("RegistrationForm.html");
			
		}
		
		else
		{
		   out.println("<script type=\"text/javascript\">");
		   out.println("alert('User or password incorrect');");
		   out.println("location='Login.html';");
		   out.println("</script>");
		}
}
}
