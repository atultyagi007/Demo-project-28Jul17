package com.model;

import java.io.Serializable;

public class Book1 implements Serializable 
{
	private int bid;
	private String bname;
	private String bcourse;
	private int bavailable;
	private int  btotal,bissue, breturn;

	public Book1() 
	{
	}

	public Book1(int bid,String bname, String bcourse, int bavailable, int btotal, int bissue, int breturn) 
	{
		this.bid = bid;
		this.bname = bname;
		this.bcourse = bcourse;
		this.bavailable = bavailable;
		this.btotal=btotal;
		this.bissue=bissue;
		this.breturn=breturn;
	}

	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBcourse() {
		return bcourse;
	}
	public void setBcourse(String bcourse) {
		this.bcourse = bcourse;
	}
	public int getBavailable() {
		return bavailable;
	}
	public void setBavailable(int bavailable) {
		this.bavailable = bavailable;
	}
	public int getBtotal() {
		return btotal;
	}

	public void setBtotal(int btotal) {
		this.btotal = btotal;
	}
	public int getBissue() {
		return bissue;
	}

	public void setBissue(int bissue) {
		this.bissue = bissue;
	}

	public int getBreturn() {
		return breturn;
	}

	public void setBreturn(int breturn) {
		this.breturn = breturn;
	}

}
