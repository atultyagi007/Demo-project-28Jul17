package com.service;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.hibernate.util.HibernateUtil;
import com.model.User1;

public class LoginService 
{
	public boolean authenticateUser(String userId, String password)
	{
		User1 user = getUserByUserId(userId);   
		if(user !=null && user.getUserId().equals(userId) && user.getPassword().equals(password))
		{
			return true;
		}
		else
		{ 
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public User1 getUserByUserId(String userId) 
	{
		Session session = HibernateUtil.getSessionImpl();
		Transaction tx = null;
		User1 uuu=null;
		List<User1> ll=null;
		try 
		{     
			tx = session.beginTransaction(); 
			Query query = session.createQuery("from User1 rt where rt.userId=?");
			query.setParameter(0,userId);
			tx.commit();
			ll =query.list();
			if(ll!=null)
		    uuu=(User1)ll.get(0);
			//System.out.println(ll.get(0));
		} 
		catch (Exception e) 
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
		finally 
		{
			session.close();
		}
		return uuu;
	}


	@SuppressWarnings("unchecked")
	public List<User1> getListOfUsers()
	{
		List<User1> list = new ArrayList<User1>();
		Session session = HibernateUtil.getSessionImpl();
		Transaction tx = null;        
		try 
		{
			tx = session.beginTransaction(); 
			list = session.createQuery("from User1").list();                        
			tx.commit();
		} 
		catch (Exception e)
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
		finally 
		{
			session.close();
		}
		return list;
	}
}
