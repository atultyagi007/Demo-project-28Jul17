package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.hibernate.util.HibernateUtil;
import com.model.Book1;
import com.model.User1;
import com.service.DB;

public class RegisterService 
{

	public static long delete(long id)
	{
		int status=0;
		Session session=null;
		Transaction tx=null;
		try
		{
			session =HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			User1 u=(User1)session.load(User1.class,id);
			session.delete(u);
			tx.commit();
			status=1;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}


	public static int update(User1 user)
	{
		int status=0;
		Session session=null;
		Transaction tx=null;
		try
		{

			session =HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			User1 u=(User1)session.load(User1.class,user.getId());
			u.setFirstName(user.getFirstName());
			u.setLastName(user.getLastName());
			u.setEmail(user.getEmail());
			u.setUserId(user.getUserId());
			u.setPassword(user.getPassword());
			session.update(u);
			tx.commit();
			status=1;			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}


	public boolean register(User1 user)
	{
		Session session = HibernateUtil.getSessionImpl();
		if(isUserExists(user)) return false;   
		Transaction tx = null; 
		try 
		{
			tx = session.beginTransaction();
			session.saveOrUpdate(user);        
			tx.commit();
		} 
		catch (Exception e) 
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
		finally 
		{
			session.close();
		}  
		return true;
	}


	public boolean isUserExists(User1 user)
	{
		Session session = HibernateUtil.getSessionImpl();
		boolean result = false;
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
			Query query = session.createQuery("from User where userId='"+user.getUserId()+"'");
			User1 u = (User1)query.uniqueResult();
			tx.commit();
			if(u!=null) result = true;
		}
		catch(Exception ex)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return result;
	}


	public List<User1> getAllRecords()
	{
		List<User1> list=new ArrayList<User1>();
		Session session=HibernateUtil.getSessionImpl();
		Transaction tx=null;
		try
		{
			tx=session.beginTransaction();
			list=session.createQuery("from User1").list();
			tx.commit();
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return list;				
		/*try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from user");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				User1 user=new User1();
				user.setId(rs.getLong(1));
				user.setFirstName(rs.getString(2));
				user.setLastName(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setUserId(rs.getString(5));
				user.setPassword(rs.getString(6));
				list.add(user);}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return list;*/
	}


	public static User1 getRecordById(long id)
	{
		Session session=null;
		Transaction tx=null;
		User1 bean=null;
		List<User1> ll=null;
		try
		{
			session=HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			Query q= session.createQuery("from User1 u where u.id=?");
			q.setParameter(0, id);
			tx.commit();
			ll=q.list();
			bean=ll.get(0);
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return bean;	
		/*try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from User where Id=?");
			ps.setLong(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){   
			bean.setId(rs.getLong(1));
			bean.setFirstName(rs.getString(2));
			bean.setLastName(rs.getString(3));
			bean.setEmail(rs.getString(4));
			bean.setUserId(rs.getString(5));
			bean.setPassword(rs.getString(6));}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return bean;*/
	}

}
