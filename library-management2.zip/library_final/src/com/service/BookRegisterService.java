package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.hibernate.util.HibernateUtil;
import com.model.Book1;
import com.service.DB;

public class BookRegisterService 
{

	public static int delete(int bid)
	{
		int status=0;
		Session session=null;
		Transaction tx=null;
		try
		{
			session =HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			Book1 b=(Book1)session.load(Book1.class,bid);
			session.delete(b);
			tx.commit();
			status=1;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}


	public static int update(Book1 book)
	{
		int status=0;
		Session session=null;
		Transaction tx=null;
		try
		{
			session =HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			Book1 u=(Book1)session.load(Book1.class,book.getBid());
			u.setBname(book.getBname());
			u.setBcourse(book.getBcourse());
			u.setBavailable(book.getBavailable());
			u.setBtotal(book.getBtotal());
			u.setBissue(book.getBissue());
			u.setBreturn(book.getBreturn());
			session.update(u);
			tx.commit();
			status=1;			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}


	public boolean register(Book1 book)
	{
		Session session = HibernateUtil.getSessionImpl();
		if(isUserExists(book)) return false;   
		Transaction tx = null; 
		try 
		{
			tx = session.beginTransaction();
			session.saveOrUpdate(book);        
			tx.commit();
		} 
		catch (Exception e) 
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
		finally 
		{
			session.close();
		}  
		return true;
	}


	public boolean isUserExists(Book1 book)
	{
		Session session = HibernateUtil.getSessionImpl();
		boolean result = false;
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
			Query query = session.createQuery("from book where bid='"+book.getBid()+"'");
			Book1 u = (Book1)query.uniqueResult();
			tx.commit();
			if(u!=null) result = true;
		}
		catch(Exception ex)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return result;
	}


	public static void updateafterissue(Book1 book) 
	{
		Session session = HibernateUtil.getSessionImpl();		
		Transaction tx = null;
		List<Book1> b=null;
		try 
		{     
			tx = session.beginTransaction(); 
			Book1 u=(Book1)session.load(Book1.class,book.getBid());
			String bname=book.getBname();
			int avail=book.getBavailable();
			int bremain=avail-1;
			int bavailable=bremain;
			int btotal=book.getBtotal();
			int bissue=btotal-bavailable;
			u.setBavailable(bavailable);
			u.setBissue(bissue);
			session.update(u);
			tx.commit();
		} 
		catch (Exception e) 
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
	}


	public static void updateafterReturn(Book1 book) 
	{
		Session session = HibernateUtil.getSessionImpl();		
		Transaction tx = null;
		List<Book1> b=null;
		try 
		{     
			tx = session.beginTransaction(); 
			Book1 u=(Book1)session.load(Book1.class,book.getBid());
			String bname=book.getBname();
			int available=book.getBavailable();
			int bavailable=available+1;
			int issue=book.getBissue();
			int bissue=issue-1;
			int return1=book.getBreturn();
			int breturn=return1+1;
			u.setBissue(bissue);
			u.setBavailable(bavailable);
			u.setBreturn(breturn);
			session.update(u);
			tx.commit();
		} 
		catch (Exception e) 
		{
			if (tx != null) 
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
	}


	//public static List<Book1> getAllRecords()
	public List<Book1> getAllRecords()
	{
		List<Book1> list=new ArrayList<Book1>();
		Session session=HibernateUtil.getSessionImpl();
		Transaction tx=null;
		try
		{
			tx=session.beginTransaction();
			//			String sql="from book";
			//			Query q=session.createQuery(sql);
			//			list=q.list();
			list=session.createQuery("from Book1").list();
			tx.commit();
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return list;			
		/*try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from book");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book1 book=new Book1();
				book.setBid(rs.getInt(1));
				book.setBname(rs.getString(2));
				book.setBcourse(rs.getString(3));
				book.setBavailable(rs.getInt(4));
				book.setBtotal(rs.getInt(5));
				book.setBissue(rs.getInt(6));
				book.setBreturn(rs.getInt(7));
				list.add(book);}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return list;*/
	}


	public static Book1 getRecordById(int bid)
	{
		//		Book1 bean=new Book1();
		//		int status=0;
		Session session=null;
		Transaction tx=null;
		Book1 bean=null;
		List<Book1> ll=null;
		try
		{
			session=HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			//String sql="from book b where b.bid=?";
			Query q= session.createQuery("from Book1 b where b.bid=?");
			q.setParameter(0, bid);
			tx.commit();
			ll=q.list();
			bean=ll.get(0);

			//			bean=(Book1)q.uniqueResult();
			//			tx.commit();
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return bean;	
		/*	try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from book where bid=?");
			ps.setInt(1,bid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){   
				bean.setBid(rs.getInt(1));
				bean.setBname(rs.getString(2));
				bean.setBcourse(rs.getString(3));
				bean.setBavailable(rs.getInt(4));
				bean.setBtotal(rs.getInt(5));
				bean.setBissue(rs.getInt(6));
				bean.setBreturn(rs.getInt(7));}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return bean;*/
	}


	public static Book1 getRecordByAvailibility(String bookName)
	{
		//		Book1 bean=new Book1();
		//		int status=0;
		Session session=null;
		Transaction tx=null;
		Book1 bean=null;
		List<Book1> ll=null;
		try
		{
			session=HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			String sql="from Book1 b where b.bname=?";
			Query q=session.createQuery(sql);
			q.setParameter(0, bookName);
			bean=(Book1)q.uniqueResult();
			tx.commit();		
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return bean;
		/*try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select  * from book where bname=?");
			ps.setString(1,bookName);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){   
				book.setBid(rs.getInt(1));
				book.setBname(rs.getString(2));
				book.setBcourse(rs.getString(3));
				book.setBavailable(rs.getInt(4));
				book.setBtotal(rs.getInt(5));
				book.setBissue(rs.getInt(6));
				book.setBreturn(rs.getInt(7));}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return book;*/
	}


	public static Book1 getBookByName(String bname)
	{
		Book1 bean=new Book1();
		//int status=0;
		Session session=null;
		Transaction tx=null;
		try
		{
			session=HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			Query q=session.createQuery("from Book1 b where b.bname=?");
			q.setParameter(0, bname);
			bean=(Book1)q.uniqueResult();
			tx.commit();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		return bean;
		/*{Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from book where bname=?");
			ps.setString(1,bname);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){   
				bean.setBid(rs.getInt(1));
				bean.setBname(rs.getString(2));
				bean.setBcourse(rs.getString(3));
				bean.setBavailable(rs.getInt(4));
				bean.setBtotal(rs.getInt(5));
				bean.setBissue(rs.getInt(6));
				bean.setBreturn(rs.getInt(7));}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return bean;*/
	}


	public static List<Book1> getAllIssued()
	{
		List<Book1> list=new ArrayList<Book1>();
		Session session=null;
		Transaction tx=null;
		try
		{
			session=HibernateUtil.getSessionImpl();
			tx=session.beginTransaction();
			String sql="from Book1 b where b.bissue>0";
			Query q=session.createQuery(sql);
			list=q.list();
			tx.commit();
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return list;
		/*try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from book where bissue>0;");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book1 book=new Book1();
				book.setBid(rs.getInt(1));
				book.setBname(rs.getString(2));
				book.setBcourse(rs.getString(3));
				book.setBavailable(rs.getInt(4));
				book.setBtotal(rs.getInt(5));
				book.setBissue(rs.getInt(6));
				book.setBreturn(rs.getInt(7));
				list.add(book);}
			con.close();}
		catch(Exception ex){System.out.println(ex);}
		return list;}*/
	}


	public static List<Book1> getAllBooks()
	{
		List<Book1> list=new ArrayList<Book1>();
		Session session=HibernateUtil.getSessionImpl();
		Transaction tx=null;
		try
		{
			tx=session.beginTransaction();
			//			String sql="from book";
			//			Query q=session.createQuery(sql);
			//			list=q.list();
			list=session.createQuery("from Book1").list();
			tx.commit();
		}
		catch(Exception e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
		}
		finally
		{
			session.close();
		}
		return list;	
	}
}