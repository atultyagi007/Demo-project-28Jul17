package com.service;

import java.sql.*;

public class DB 
{
	public static Connection getCon()
	{
		Connection con=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver"); 
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ns1","root","Golu@#5891"); 
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return con;
	}
}
