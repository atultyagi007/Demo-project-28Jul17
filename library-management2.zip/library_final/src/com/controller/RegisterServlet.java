package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.model.User1;
import com.service.RegisterService;

public class RegisterServlet extends HttpServlet
{
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");
		String userId = request.getParameter("userId");
		String password = request.getParameter("password");

		User1 user = new User1(firstName,lastName, email,userId, password);
		SessionFactory  sessionFactory=null;     
		Session session=null;     
		try 
		{  
			RegisterService registerService = new RegisterService();

			boolean result = registerService.register(user);       
			out.println("<html>");
			out.println("<head>");       
			out.println("<title>Registration Successful</title>");     
			out.println("</head>");
			out.println("<body  background=book4.jpg>");
			out.println("<center>");
			if(result)
			{
				out.println("<h1>Added Successfully!! :</h1>");
				out.println("To Go Back:<a href=admin_in.jsp>Click here</a>");
			}
			else
			{
				out.println("<script type='text/javascript'>alert('Unsuccessful!!')</script>");
			}
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		} 
		finally 
		{        
			out.close();
		}
	}
}
