package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.User1;
import com.service.RegisterService;

public class ViewServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Welcome to Library!!</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body background='book4.jpg'>");
		out.println("<div class='container'>");
		out.print("<h1><center><u>Librarian's Database</u></center></h1>");

		RegisterService rs= new RegisterService();
		List<User1> list=rs.getAllRecords();
		out.println("<table class='table table-bordered' border='1' width='100%'>");
		out.print("<tr><th>First Name</th><th>Last Name</th><th>Email</th><th>User ID</th><th>Password</th><th>Edit</th><th>Delete</th>");
		for(User1 user:list)
		{
			System.out.println("ID :"+user.getId());
			out.print("<tr><td>" +user.getFirstName()+ "</td><td>" +user.getLastName()+ "</td><td>" +user.getEmail()+ "</td><td>" +user.getUserId()+ "</td><td>" +user.getPassword()+ "</td> <td><a href='EditLibrarianForm?Id=" +user.getId()+ "'>Edit</a></td><td><a href='DeleteServlet?id=" +user.getId()+ "'>Delete</a></td></tr>");
		}
		out.println("</table><br>");
		out.print("<h4><center><a href='admin_in.jsp'>Go Back</a></center></h4>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}
