package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.Book1;
import com.service.BookRegisterService;

public class BookViewServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Welcome to Library!!</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body background='book4.jpg'>");
		out.println("<div class='container'>");
		out.print("<h1><center><u>Book Database</u></center></h1>");

		BookRegisterService rs= new BookRegisterService();
		List<Book1> list=rs.getAllRecords();
		out.println("<table class='table table-bordered table-striped' border='1' width='100%'>");

		out.print("<tr><th>Book Name</th><th>Course</th><th>Availability</th><th>Total</th><th>Issued</th><th>Returned</th><th>Edit</th><th>Delete</th>");
		for(Book1 book:list)
		{
			System.out.println("Book ID :"+book.getBid());
			out.print("<tr><td>" +book.getBname()+ "</td><td>" +book.getBcourse()+ "</td><td>" +book.getBavailable()+ "</td><td>" +book.getBtotal()+ "</td><td>" +book.getBissue()+ "</td><td>" +book.getBreturn()+ "</td><td> <a href='EditBookForm?bid=" +book.getBid()+ "'>Edit</a></td><td><a href='BookDeleteServlet?bid=" +book.getBid()+ "'>Delete</a></td></tr>");
		}
		out.println("</table><br>");
		out.print("<h4><center><a href='librarian_in.jsp'>Go Back</a></center></h4>");

		out.println("</div>");
		out.println("</body>");
		out.println("</html>");

		out.close();
	}
}
