package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.User1;
//import com.model.User2;
import com.service.RegisterService;
//import com.service1.RegisterService1;

@WebServlet("/EditLibrarian")
public class EditLibrarian extends HttpServlet 
{
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		long id=Long.parseLong(request.getParameter("id"));
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("email");
		String userId=request.getParameter("userId");
		String password=request.getParameter("password");

		User1 user=new User1 (firstName, lastName,email,userId, password);
		user.setId(id);
		RegisterService.update(user);
		System.out.println("successfully updated record");
		response.sendRedirect("ViewServlet");
		out.close();
	}
}
