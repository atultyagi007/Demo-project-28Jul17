package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;
import com.model.User1;
//import com.model.User2;
//import com.service.RegisterService;
//import com.service1.RegisterService1;
import com.service.RegisterService;

@WebServlet("/EditLibrarianForm")
public class EditLibrarianForm extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Session session=null;
		PrintWriter out=response.getWriter();
		String suserId=request.getParameter("Id");
		long userId=Long.parseLong(suserId);	
		User1 user=RegisterService.getRecordById(userId);

		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Edit Librarian</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body  background='book4.jpg'>");
		out.println("<center>");
		out.println("<div class='container'>");

		out.print("<h1><u><center>Edit Librarian Form</center></u></h1>");
		out.print("<form action='EditLibrarian' method='post'>");
		System.out.println("firstName :"+user.getFirstName());
		System.out.println(user.getLastName());
		System.out.println(user.getEmail());
		System.out.println(user.getUserId());
		System.out.println(user.getPassword());
		System.out.println(user.getId());

		out.print("<table>");
		out.print("<tr><td  hidden='true'>ID:</td><td><input type='hidden' name='id' value='"+user.getId()+"' /></td></tr>");
		out.print("<tr><td>First Name:</td><td><input type='text' name='firstName' value='"+user.getFirstName()+"'/></td></tr>");
		out.print("<tr><td>Last Name:</td><td><input type='text' name='lastName' value='"+user.getLastName()+"'/></td></tr>");
		out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"+user.getEmail()+"'/></td></tr>");
		out.print("<tr><td>User ID:</td><td><input type='text' name='userId' value='"+user.getUserId()+"'/></td></tr>");
		out.print("<tr><td>Password:</td><td><input type='text' name='password' value='"+user.getPassword()+"'/></td></tr>");
		out.print("<tr><td colspan='2'><center><input type='submit' value='update'/></center></td></tr>");
		out.print("</table>");

		out.print("</form>");
		out.println("</div>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}
