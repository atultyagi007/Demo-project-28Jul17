package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;
import com.model.Book1;
import com.service.BookRegisterService;

@WebServlet("/EditBookForm")
public class EditBookForm extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Session session=null;
		PrintWriter out=response.getWriter();
		String bookid=request.getParameter("bid");
		int b=Integer.parseInt(bookid);	
		Book1 book=BookRegisterService.getRecordById(b);

		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Edit Librarian</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body  background='book4.jpg'>");
		out.println("<center>");
		out.println("<div class='container'>");

		out.print("<h1><u><center>Edit Book Form</center></u></h1>");
		out.print("<form action='EditBook' method='post'>");
		System.out.println("Book Name :"+book.getBname());
		System.out.println(book.getBcourse());
		System.out.println(book.getBavailable());
		System.out.println(book.getBtotal());
		System.out.println(book.getBissue());
		System.out.println(book.getBreturn());

		out.print("<table>");
		out.print("<tr><td hidden='true'>Book ID:</td><td><input type='hidden' name='bid' value='"+book.getBid()+"' /></td></tr>");
		out.print("<tr><td>Book Name:</td><td><input type='text' name='bname' value='"+book.getBname()+"'/></td></tr>");
		out.print("<tr><td>Course:</td><td><input type='text' name='bcourse' value='"+book.getBcourse()+"'/></td></tr>");
		out.print("<tr><td>Availability:</td><td><input type='text' name='bavailable' value='"+book.getBavailable()+"'/></td></tr>");
		out.print("<tr><td>Total:</td><td><input type='text' name='btotal' value='"+book.getBtotal()+"'/></td></tr>");
		out.print("<tr><td>Issued:</td><td><input type='text' name='bissue' value='"+book.getBissue()+"'/></td></tr>");
		out.print("<tr><td>Returned:</td><td><input type='text' name='breturn' value='"+book.getBreturn()+"'/></td></tr>");
		out.print("<tr><td colspan='2'><center><input type='submit' value='update'/></center></td></tr>");
		out.print("</table>");
		
		out.print("</form>");
		out.println("</div>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}
