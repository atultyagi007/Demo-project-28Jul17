package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.Book1;
import com.service.BookRegisterService;

@WebServlet("/SearchBook")
public class SearchBook extends HttpServlet 
{
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		String sbname=request.getParameter("bname");
		Book1 bean=BookRegisterService.getBookByName(sbname);

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Welcome to Library!!</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body background='book4.jpg'>");
		out.println("<div class='container'>");
		out.print("<h1><center><u>Search Book</u></center></h1>");

		if(bean!=null)
		{
			out.println("<table class='table table-bordered table-striped' border='1' width='100%'>");
			out.print("<tr><th>Book ID</th><th>Book Name</th><th>Course</th><th>Availability</th><th>Total</th><th>Issued</th><th>Returned</th>");
			out.print("<tr><td>" +bean.getBid()+ "</td><td>" +bean.getBname()+ "</td><td>" +bean.getBcourse()+ "</td><td>" +bean.getBavailable()+ "</td><td>" +bean.getBtotal()+ "</td><td>" +bean.getBissue()+ "</td><td>" +bean.getBreturn()+ "</td></tr>");
			out.println("</table><br>");
		}
		else
		{
			out.println("<p>Sorry, No Record found.</p>");
		}

//catch(Exception e)
//{
//	out.println("<p>Sorry, No Record found.</p>");	
//}
		out.print("<h4><center><a href='librarian_in.jsp'>Go Back</a></center></h4>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}
