package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.service.RegisterService;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		long lid=Long.parseLong(request.getParameter("id"));
		RegisterService.delete(lid);
		response.sendRedirect("ViewServlet");
	}
}


