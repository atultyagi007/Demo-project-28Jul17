package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.Book1;
import com.service.BookRegisterService;

@WebServlet("/EditBook")
public class EditBook extends HttpServlet 
{
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		int bid=Integer.parseInt(request.getParameter("bid"));
		String bname=request.getParameter("bname");
		String bcourse=request.getParameter("bcourse");
		int bavailable=Integer.parseInt(request.getParameter("bavailable"));
		int btotal=Integer.parseInt(request.getParameter("btotal"));
		int bissue=Integer.parseInt(request.getParameter("bissue"));
		int breturn=Integer.parseInt(request.getParameter("breturn"));

		Book1 book=new Book1 (bid,bname,bcourse,bavailable,btotal,bissue,breturn);
		book.setBid(bid);
		BookRegisterService.update(book);
		System.out.println("successfully updated record");
		response.sendRedirect("BookViewServlet");

		out.close();
	}
}
