package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;
import com.hibernate.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.hibernate.util.HibernateUtil;
import com.model.Book1;
import com.service.BookRegisterService;

@WebServlet("/IssueBook")
public class IssueBook extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException 
	{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String bookName=request.getParameter("bName");
		Book1 book=BookRegisterService.getRecordByAvailibility(bookName);
		int bav=book.getBavailable();

		try 
		{        
			out.println("<html>");
			out.println("<head>");       
			out.println("<title>Successful</title>");     
			out.println("</head>");
			out.println("<body background=book4.jpg>");
			out.println("<center>");
			if(bav!=0)
			{ 		

				out.println("<h1>Issued Successfully!! </h1>");
				out.println("To Go Back:<a href=librarian_in.jsp>Click here</a>");
				BookRegisterService.updateafterissue(book);							
			}
			else
			{
				out.println("<script type='text/javascript'>alert('Book is not available.')</script>");
			}
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		}
		finally 
		{        
			out.close();
		}
	}
}