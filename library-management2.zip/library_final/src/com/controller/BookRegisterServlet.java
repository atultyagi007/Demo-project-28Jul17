package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.model.Book1;
import com.service.BookRegisterService;

public class BookRegisterServlet extends HttpServlet
{
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		int bid = Integer.parseInt(request.getParameter("bid"));
		String bname = request.getParameter("bname");
		String bcourse = request.getParameter("bcourse");
		int bavailable = Integer.parseInt(request.getParameter("bavailable"));
		int btotal = Integer.parseInt(request.getParameter("btotal"));
		int bissue = Integer.parseInt(request.getParameter("bissue"));
		int breturn = Integer.parseInt(request.getParameter("breturn"));

		Book1 book = new Book1(bid,bname,bcourse,bavailable,btotal, bissue,breturn);
		SessionFactory  sessionFactory=null;     
		Session session=null;     
		try 
		{  
			BookRegisterService brs = new BookRegisterService();		  
			boolean result = brs.register(book);       
			out.println("<html>");
			out.println("<head>");       
			out.println("<title>Registration Successful</title>");     
			out.println("</head>");
			out.println("<body  background=book4.jpg>");
			out.println("<center>");
			if(result)
			{
				out.println("<h1>Added Successfully!! :</h1>");
				out.println("To Go Back:<a href=librarian_in.jsp>Click here</a>");
			}
			else
			{
				out.println("<script type='text/javascript'>alert('Unsuccessful!!')</script>");
			}
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		} 
		finally 
		{        
			out.close();
		}
	}
}
