package overloading;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


public class FutureTaskWithRunnable {

    public static void main(String[] args) {
    	MyRunnableTask myRunnableTask1 = new MyRunnableTask(1000);
    	MyRunnableTask myRunnableTask2 = new MyRunnableTask(2000);
    	
    	//only fix value can return like this
        FutureTask<String> futureTask1 = new FutureTask<String>(myRunnableTask1,"Task1");
        FutureTask<Boolean> futureTask2 = new FutureTask<Boolean>(myRunnableTask2,true);

        ExecutorService executor = Executors.newFixedThreadPool(2);
        executor.execute(futureTask1);
        executor.execute(futureTask2);

        while (true) {
            try {
                if(futureTask1.isDone() && futureTask2.isDone()){
                    System.out.println("Done");
                    //shut down executor service
                    executor.shutdown();
                    return;
                }

                if(!futureTask1.isDone()){
                //wait indefinitely for future task to complete
                System.out.println("FutureTask1 output="+futureTask1.get());
                }

                System.out.println("Waiting for FutureTask2 to complete");
                //wait only 200 milliseconds overloaded get () method in Future Interface
                Boolean s = futureTask2.get(200L, TimeUnit.MILLISECONDS); 
                if(s){
                    System.out.println("FutureTask2 output="+s);
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }catch(TimeoutException e){
                //do nothing
            }
        }

    }

}

class MyRunnableTask implements Runnable {

    private long waitTime;

    public MyRunnableTask(int timeInMillis){
        this.waitTime=timeInMillis;
    }
    //run method of Runnable Can not return only call method of callable can return
    @Override
    public void run(){
    	System.out.println(Thread.currentThread().getName());
    }
    /*public String run() throws Exception {
        Thread.sleep(waitTime);
        //return the thread name executing this callable task
        return Thread.currentThread().getName();
    }*/

}

