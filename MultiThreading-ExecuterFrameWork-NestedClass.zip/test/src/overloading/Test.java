package overloading;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		Parent obj = new Parent();
		obj.test();
		//obj.Parent();
		System.out.println("inside main 1");
		try{
		obj.go(1,2);
		}
		/*catch (Exception e){
		System.out.println("catch");	
		}*/
		finally{
			
		}
		System.out.println("inside main 2");
		obj.go(1l,2);
		byte b1=3;
		byte b2=3;
		//obj.go(b1,5);
		//validate(13);
		/*try{
		
		}*/ /*catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}*/
		/*finally {
			
		}
		*/
		//compile();
	}
	static void validate(int age) throws InvalidAgeException{  
	     if(age<18)  
	      throw new InvalidAgeException("not valid");  
	     else  
	      System.out.println("welcome to vote");  
	   } 
	static void compile() throws FileNotFoundException{
		//FileReader fr=new FileReader("abc");
		throw new FileNotFoundException();
		/*try{
		FileReader fr=new FileReader("abc");
		}catch(FileNotFoundException e){
			
		}*/
		
	}
	     
}

class Parent{
	void test(){
		int a;
		//int r=10/a;
		
	}
	 void go(byte b,long l) throws Exception{
		
	}
	  Parent(){
		 System.out.println("constructor");
		 return;
	 }
	 void go(int l, int i) {
		 System.out.println("inside go");
		 try{
		 throw new IOException();
		 }catch (Exception e){
			 
		 }
		 finally {
				
			}
		 
		 
	 }
void go(long l, long i){
		 
	 }


}


class Child extends Parent {
	public int go() throws IOException{
		
		throw new IOException();
		
		
	}
	
}

class InvalidAgeException extends Exception{  
	 InvalidAgeException(String s){  
	  super(s);  
	 }  
	}

