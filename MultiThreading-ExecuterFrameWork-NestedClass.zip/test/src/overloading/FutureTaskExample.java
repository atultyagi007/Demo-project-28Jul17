package overloading;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class FutureTaskExample {

    public static void main(String[] args) {
    	MyCallableTest callable1 = new MyCallableTest(1000);
    	MyCallableTest callable2 = new MyCallableTest(2000);

        FutureTask futureTask1 = new FutureTask(callable1); //Raw type
        FutureTask<String> futureTask2 = new FutureTask<String>(callable2); //Generic  type

        ExecutorService executor = Executors.newFixedThreadPool(2);
        executor.execute(futureTask1);
        executor.execute(futureTask2);

        while (true) {
            try {
                if(futureTask1.isDone() && futureTask2.isDone()){
                    System.out.println("Done");
                    //shut down executor service
                    executor.shutdown();
                    return;
                }

                if(!futureTask1.isDone()){
                //wait indefinitely for future task to complete
                System.out.println("FutureTask1 output="+futureTask1.get());
                }

                System.out.println("Waiting for FutureTask2 to complete");
                //wait only 200 milliseconds overloaded get () method in Future Interface
                String s = futureTask2.get(200L, TimeUnit.MILLISECONDS); 
                if(s !=null){
                    System.out.println("FutureTask2 output="+s);
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }catch(TimeoutException e){
                //do nothing
            }
        }

    }

}

class MyCallableTest implements Callable {

    private long waitTime;

    public MyCallableTest(int timeInMillis){
        this.waitTime=timeInMillis;
    }
    @Override //always return with call method
    public String call() throws Exception {
        Thread.sleep(waitTime);
        //return the thread name executing this callable task
        return Thread.currentThread().getName();
    }
    
   /* public Void  call() throws Exception {
        Thread.sleep(waitTime);
        //return the thread name executing this callable task
        //return Thread.currentThread().getName();
        return null;
        
    }*/
    
}

