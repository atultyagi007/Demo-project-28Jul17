package overloading;

abstract interface Eatable{ 
	final int i=1999;
	public abstract void eat();  
	}  

/*class TestEat{
	
	int
}*/


public class TestNested {
	
	public static void main(String[] args) {
		
		 new  Eatable(){
			 public void eat(){
				 System.out.println("Inside anonymous a="+10);
				 
			 }
			 void go(){
				 System.out.println("Anonimus class with overriding method and more methods");
			 }
			
			 
		 }.eat();
		 
		
		Nested obj= new Nested(10,20);
		Nested objThread= new Nested(new Eatable() {
			final int i=1;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		objThread.start();
		
		Nested objThread2= new Nested(new Eatable() {
			final int i=2;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		objThread2.start();
		
		Nested objThread3= new Nested(new Eatable() {
			final int i=3;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		objThread3.start();

		
		Nested objThread4= new Nested(new Eatable() {
			final int i=4;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		objThread4.start();

		Nested objThread5= new Nested(new Eatable() {
			final int i=5;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		objThread5.start();


		
		
		
		
		/*obj.testAn(new Eatable() {
			final int i=1;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
		
obj.testAn(new Eatable() {
	final int i=2;
			@Override
			public void eat() {
				System.out.println(i);
				// TODO Auto-generated method stub
				
			}
		});
obj.testAn(new Eatable() {
	final int i=3;
	
	@Override
	public void eat() {
		System.out.println(i);
		// TODO Auto-generated method stub
		
	}
});
obj.testAn(new Eatable() {
	final int i=4;
	@Override
	public void eat() {
		System.out.println(i);
		// TODO Auto-generated method stub
		
	}
});
obj.testAn(new Eatable() {
	final int i=5;
	@Override
	public void eat() {
		System.out.println(i);
		// TODO Auto-generated method stub
		
	}
});*/
		
		obj.display();
		obj.anObj.eat();
		
		//obj.anObj.go();
		//System.out.println(obj.a+"="+obj.b);
		/*Nested.InnerChild objInner= new Nested(100,1000).new InnerChild();
		Nested.NestedChild objNested=new Nested.NestedChild();
		objNested.msg();*/
		//System.out.println(objInner.ic);
		//objInner.msg();
		
	}
}

class Nested extends Thread{
	Eatable eat=null;
	Nested(Eatable eat){
		this.eat=eat;
	}
		public void run() {
			System.out.println(this.currentThread().getName());
			testAn(eat);
			
		}
	
	
	 private int a=11;
	 private int a12=123;
	 int b=11;
	static String name="tested";
	final static int constantLike=99;
	final int constantLike2=99;
	static int test2=9999;
	Nested(int a, int bb){
		this.a=a;
		b=bb;
	}
	
	void checkNested(){
		System.out.println(Nested.this.a);
		System.out.println(this.a);
	}
	private static class NestedChild {
		 
		 void msg(){
			 final int nc;
			 System.out.println(name);
			 //System.out.println(a);
			 Nested obj= new Nested(50,500);
			 System.out.println(obj.a);
			 nc=12;
			 //nc=1222;
			 System.out.println("inside Nested static class "+nc);
		 }
		
	}
	 class InnerChild{ 
		 private int ic=50;
		 private int a12=1000;
		 void msg(){
			 System.out.println("constantLike "+constantLike);
			 System.out.println("constantLike2 "+constantLike2);
			// constantLike2=123;
			 System.out.println("test2"+test2);
			 System.out.println("className.this test");
			 System.out.println(Nested.this.a12);
			 System.out.println(a12);
			 System.out.println(this.a12);
			 System.out.println(InnerChild.this.a12);
			 
			 System.out.println(name);
			 System.out.println(a);
		 System.out.println("inside Inner or non static nested class a="+a);
		 }
		 
	 }
	 
	 private int data=30;//instance variable  
	 void display(){  
	  int value=50;//local variable must be final till jdk 1.7 only 
	  final int value2=20;
	  System.out.println("display="+value2);
	  class Local{  //local Inner class
	   void msg(){System.out.println("display="+value);System.out.println("a="+a);}  
	  }  
	  Local l=new Local();  
	  l.msg();  
	 } 
	 
	 void display2(){  
		  final int value=50;//local variable must be final till jdk 1.7 only
		  Object obj;
		  
		  
		
		  class Local{  //local Inner class
		   void msg(){System.out.println("display="+value);System.out.println("a="+a);}  
		  }  
		  Local l=new Local();  
		  l.msg();  
		 } 
	 
	  Eatable anObj= new  Eatable(){
		 public void eat(){
			 System.out.println("Inside anonymous a="+a);
			 
		 }
		 void go(){
			 System.out.println("Anonimus class with overriding method and more methods");
		 }
		
		 
	 };
	 
	 
	 
	 void testAn(Eatable e){
		 e.eat();
		 
	 }
	 
	 
	 Eatable anObj2= new Eatable(){
		 public void eat(){
			 System.out.println("Inside anonymous a="+a);
			 
		 }
	 };
	 
	 
}

class TestAnnonymousInner1{  
	 public static void main(String args[]){  
	 Eatable e=new Eatable(){  
	  public void eat(){System.out.println("nice fruits");
	  }  
	 };  
	 e.eat();  
	 }  
	}  


