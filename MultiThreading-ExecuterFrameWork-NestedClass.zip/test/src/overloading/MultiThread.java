package overloading;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class MultiThread extends Thread{
	/*public void run1(){
		System.out.println(Thread.currentThread().getName());
		
	}*/
	public void run(){
		System.out.println("mainnnn "+this.currentThread().getName());
		
	}
	
public static void main(String[] args) {
	MultiThread obj= new MultiThread();
	obj.run();
	
	MultiThread obj2= new MultiThread();
	Thread runth= new Thread(obj2);
	runth.start();
	
	Calendar cal = Calendar.getInstance();
	SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
	System.out.println(df.format(cal.getTime()));
	
	Thread th1= new Thread(new Runnable(){  //from Anonymous Runnable Interface class 
		public void run(){
			System.out.println(Thread.currentThread().getName());
			System.out.println(this.getClass().getName());
			try{
				Thread.sleep(2);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			System.out.println("1");
			
		}
	});
	Thread th2= new Thread(){  //from Anonymous Thread class 
		public void run(){
			System.out.println(Thread.currentThread().getName());
			System.out.println(this.getClass().getName());
			try{
			Thread.sleep(2);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println("2");
			
		}
		
	};
	 new Thread(new Runnable(){ //calling directly start method ass like other normal method
		public void run(){
			
			System.out.println(Thread.currentThread().getName());
			System.out.println(this.getClass().getName());
			try{
				Thread.sleep(2);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			System.out.println("3");
			
		}
		
	}).start();
	
	th1.start();
	th2.start();
	
	/*th1.run();
	th2.run();
	th3.run();*/

	Calendar cal2 = Calendar.getInstance();
	SimpleDateFormat df2 = new SimpleDateFormat("HH:mm:ss");
	System.out.println(df2.format(cal2.getTime()));
}


}

class TestThread implements Runnable{
	public void run(){
		
	}
	
}

